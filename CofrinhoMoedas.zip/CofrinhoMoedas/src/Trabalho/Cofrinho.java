package Trabalho;

import java.util.ArrayList;

public class Cofrinho{	
	
	private ArrayList<Moeda> listaMoedas = new ArrayList<>();
		
	
	public void adicionar(Moeda m) {
		listaMoedas.add(m);
		System.out.println("Moeda adicionada!");
	}
	
	// método que remove a moeda com base no índice dela na lista
	public void remover(int index) {
		if (index >= 0 && index < listaMoedas.size()) {
            listaMoedas.remove(index);
            System.out.println("Moeda removida!");
        } else {
            System.out.println("Índice inválido!");
        }	
	}
	
	// encontrei na internet esse jeito de fazer a listagem,
	// Parece ser algo mais avançado, mas resolvi implementar
    public void listarMoedas() {
        for (int i = 0; 
        		i < listaMoedas.size(); 
        		i++) {
            System.out.println(i + 1 + ". " + 
            		listaMoedas.get(i).getClass().getSimpleName() 
            		+" - Valor: " + listaMoedas.get(i).valor);
        }
    }
	// emétodo que calcula o valor total convertido em real
    public double totalConvertido() {
        return listaMoedas.stream().mapToDouble(Moeda::converter).sum();

		
	}
}
