package Trabalho;

public class Dolar extends Moeda {
	//construtor
	public Dolar(double valor) {
		super(valor);
	}
	@Override
	public double converter() {
		return valor * 5.3;
	}

	@Override
	public void info() {
		
	}
	
}
