package Trabalho;

public class Euro extends Moeda {
	//construtor
	public Euro(double valor) {
		super(valor);
	}

	@Override
	public void info() {
		
	}

	@Override
	public double converter() {
		return valor * 6.2;
	}

}
