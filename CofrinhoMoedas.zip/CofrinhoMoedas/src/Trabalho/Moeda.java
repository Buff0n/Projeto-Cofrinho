package Trabalho;

public abstract class Moeda {

	double valor;

	//construtor
	public Moeda(double valor) {
		this.valor = valor;
	}
	
	//getter e setter

	public double getValor() {
		return valor;
	}

	public void setValor(double valor) {
		this.valor = valor;
	}
	public abstract void info();
	
	public abstract double converter();
}
