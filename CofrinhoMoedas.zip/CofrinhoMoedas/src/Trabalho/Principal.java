package Trabalho;

import java.util.Scanner;

public class Principal {

	public static void main(String[] args) {
		//Tive que pesquisar e adotar a instrução try-with-resources
		//para resolver o erro: InputMismatchException
        try (Scanner teclado = new Scanner(System.in)) {
            Cofrinho cofre = new Cofrinho();

            while (true) {
                System.out.println("MENU");
                System.out.println("1 - Adicionar Moeda");
                System.out.println("2 - Remover Moeda");
                System.out.println("3 - Listar Moedas");
                System.out.println("4 - Valor total das Moedas convertido para Real");
                System.out.println("0 - ENCERRAR");
                int opcao = teclado.nextInt();
                teclado.nextLine();

                switch (opcao) {
                    case 1:
                        // Menu adicionar
                        System.out.println("Que moeda deseja adicionar?");
                        System.out.println("1-Dolar");
                        System.out.println("2-Euro");
                        System.out.println("3-Real");
                        int tipoMoeda = teclado.nextInt();
                        // nextLine() para consumir nova linha
                        // demorei pra encontrar isso.
                        teclado.nextLine();

                        System.out.println("Informe o valor da Moeda");
                        //precisei corrigir o erro InputMismatchException 
                        //devido o método nextDouble não conseguir ler um número tipo double
                        //loop para garantir que o valor seja lido corretamente 
                        //como um número decimal
                        //o Double.parseDouble é para converter a entrada em uma 
                        //representação flot (double)
                        double valor = 0.0;
                        while (true) {
                            try {
                                valor = Double.parseDouble(teclado.nextLine());
                                break;
                            } catch (NumberFormatException e) {
                                System.out.println("Valor inválido. Informe novamente:");
                            }
                        }

                        Moeda novaMoeda;
                        switch (tipoMoeda) {
                            case 1:
                                novaMoeda = new Dolar(valor);
                                break;
                            case 2:
                                novaMoeda = new Euro(valor);
                                break;
                            case 3:
                                novaMoeda = new Real(valor);
                                break;
                            default:
                                System.out.println("Tipo de moeda inválido.");
                                System.out.println("Tente novamente!");
                                continue;
                        }
                        cofre.adicionar(novaMoeda);
                        break;

                    case 2:
                        // Pede o índice da moeda para ser removida
                        System.out.println("Informe o índice da moeda a ser removida:");
                        int indiceRemover = teclado.nextInt();
                        teclado.nextLine();
                        cofre.remover(indiceRemover - 1);
                        break;

                    case 3:
                        // listar
                        cofre.listarMoedas();
                        break;

                    case 4:
                        // converter total em real
                        System.out.println("Total em Real: " + cofre.totalConvertido());
                        break;

                    case 0:
                        System.out.println("FIM. :)");
                        System.exit(0);
                        break;

                    default:
                        System.out.println("OPÇÃO INVÁLIDA!");
                        break;
                }
            }
        }
    }
}
