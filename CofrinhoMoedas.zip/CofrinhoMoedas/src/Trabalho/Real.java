package Trabalho;

public class Real extends Moeda {
	//construtor
	public Real(double valor) {
		super(valor);
	}

	@Override
	public void info() {
		
	}

	@Override
	public double converter() {
		return valor;
	}

}
